# 1 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
# 1 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
# 2 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino" 2
# 3 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino" 2
// Macro debug def
# 26 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
// 12 v realy pins





// 24 relay pins





//8 channel receiver
int ch[8];

IBT base(6, 7); // wiper on base
IBT act1wrist360(10, 11); // actuator1 and wrist360
IBT act2(14, 15); // actuator2
IBT rpg(8, 9); // roll pitch grabber in a single relay
IBT left(12, 12);
IBT right(12, 12);
//
//IBT base(10, 11);         // wiper on base
//IBT act1wrist360(6, 7); // actuator1 and wrist360
//IBT act2(14, 15);         // actuator2
//IBT rpg(8, 9);            // roll pitch grabber in a single relay
//IBT left(12, 12);
//IBT right(12, 12);


/////////////////ba, ac1, ac2, roll, pitc, w, g
String arm_names[] = {
    "Base",
    "Act1",
    "Act2",
    "Roll",
    "Pitc",
    "Wrst",
    "Grab",
};





SBUS sbus(Serial1);
int mode; // mannual auto semi_auto serial
String inputString = ""; // a string to hold incoming data
boolean stringComplete = false; // whether the string is complete

void setup()
{
  Serial.begin(57600);
  sbus.begin(true);
  // reserve 200 bytes for the inputString:
  inputString.reserve(200);
  //receiver setup
  setup_relays();

}

extern "C" void __vector_13 (void) __attribute__ ((signal,used, externally_visible)) ; void __vector_13 (void)
{
  sbus.process();
}

void loop()
{
  //  act1wrist360.rotPos(200);
  //  delay(2000);
  //  act1wrist360.rotPos(0);
  //  delay(1000);
  //  act1wrist360.rotPos(-200);
  //  delay(2000);
  //  act1wrist360.rotPos(0);
  //  delay(1000);
  test();
}

void test()
{
//     only_rf_full();
  // only_serial_full();
  //   reciever_test();
  // print the string when a newline arrives:
  if (stringComplete)
  {
    Serial.println(inputString);
    handle_serial(inputString);
    // clear the string:
    inputString = "";
    stringComplete = false;
  }

}


/*
  SerialEvent occurs whenever a new data comes in the
  hardware serial RX.  This routine is run between each
  time loop() runs, so using delay inside loop can delay
  response.  Multiple bytes of data may be available.
*/
void serialEvent()
{
  while (Serial.available())
  {
    // get the new byte:
    char inChar = (char)Serial.read();
    // add it to the inputString:
    inputString += inChar;
    // if the incoming character is a newline, set a flag
    // so the main loop can do something about it:
    if (inChar == '\n')
    {
      stringComplete = true;
    }
  }
}

// void serialevent()
// {
//   if (Serial.available())
//   {
//    while (Serial.available())
//     {
//       var = Serial.read();
//       if (var == '\n')
//       {
//         while (Serial.available())
//           var = Serial.read();
//         break;
//       }
//       IncomingData += String(var);
//     }
//     Serial.println(IncomingData);
//     dir = (char)IncomingData[0];
//     num1 = IncomingData.substring(0, 4).toInt();
//     num2 = IncomingData.substring(4, 8).toInt();
//     num3 = IncomingData.substring(8, 12).toInt();
//     x = num1;
//     y = num2;
//     z = num3;
//     Serial.print("x : ");
//     Serial.print(x);
//     Serial.print(" y : ");
//     Serial.print(y);
//     Serial.print(" z : ");
//     Serial.println(z);
//     while (Serial.available())
//       var = Serial.read();
//     IncomingData = "";
//   }
// }

// void armtest()
// {
//   while (Serial.available())
//   {
//     char c = Serial.read();
//     if (c == 'q')
//       pitch.rotPos(150);
//     if (c == 'z')
//       pitch.rotNeg(150);
//     if (c == 'a')
//       pitch.stop();

//     if (c == 'w')
//       roll.rotPos(150);
//     if (c == 'x')
//       roll.rotNeg(150);
//     if (c == 's')
//       roll.stop();

//     if (c == 'e')
//       act2.rotPos(250);
//     if (c == 'c')
//       act2.rotNeg(250);
//     if (c == 'd')
//       act2.stop();

//     if (c == 'r')
//       act1.rotPos(250);
//     if (c == 'v')
//       act1.rotNeg(250);
//     if (c == 'f')
//       act1.stop();
//   }
// }

//  mode = get_mode();
// mode = MANUAL;
// if (mode == AUTO)
// {
//   automate();
// }
// else {
//   handle_rf();
// }
# 1 "F:\\erc2018\\github\\manoeuvre\\RECIEVER.ino"


void reciever_test()
{
  for (int channel_id = 1; channel_id <= 10; channel_id++)
  {
    Serial.print("Ch");
    Serial.print(channel_id);
    Serial.print(' ');
    Serial.print(sbus.getChannel(channel_id));
    Serial.print('\t');
  }
  Serial.println();
}

int temp_ch;
int get_pwm_input_from_rf(byte channel_id)
{
  /* 

  * Method getNormalizedChannel return -100 to +100

  * so to convert into PWM values 2.5 is multiplied 

  * to get a eange of -255 to 255

  */
# 24 "F:\\erc2018\\github\\manoeuvre\\RECIEVER.ino"
  int pwm = (int)sbus.getNormalizedChannel((int)channel_id) * 2.5;

  if (((pwm)>0?(pwm):-(pwm)) < 40)
    pwm = 0;

  return pwm;
}
# 1 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
bool near(int from, int to, int tolerance)
{
  if (((from - to)>0?(from - to):-(from - to)) <= tolerance)
    return true;
  return false;
}

bool near(double from, double to, double tolerance)
{
  if (((from - to)>0?(from - to):-(from - to)) <= tolerance)
    return true;
  return false;
}

bool near(double from, double to, int tolerance)
{
  if (((from - to)>0?(from - to):-(from - to)) <= tolerance)
    return true;
  return false;
}

double rad2deg(double rad)
{
  return ((rad * 57296) / 1000);
}

int middle_out(int value)
{
  if (value < 0 and ((value)>0?(value):-(value)) < 40)
    value = (-1) * 40;
  else if (value > 0 and ((value)>0?(value):-(value)) < 40)
    value = 40;
  return value;
}

// void sonar_test()
// {
//   Serial.print("Act 1: ");
//   Serial.print(sonar_act1.get_distance());
//   Serial.print('\t');
//   Serial.print("Act 2: ");
//   Serial.print(sonar_act2.get_distance());
//   Serial.println();
// }
# 1 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
// --------------------------------
void handle_serial(String cmd)
{
  int speed;
  for (int i = 0; i < 3; i++)
  {
    Serial.print(cmd[i]);
    if (cmd[i] == '+')
      speed = 200;
    else if (cmd[i] == '-')
      speed = -200;
    else
      speed = 0;
    move_it(i, speed);
  }
    Serial.println("---------");
}
// ---------------------------------- Fully manual control

int channel[7] = {
    //channel name index
    7, // base  0
    2, // ac1   1
    3, // ac2   2
    6, // roll  3
    5, //pitch  4
    4, //wrist  5
    1, //grabb  6
};
int available = 10;

void only_rf_full()
{
//  if (get_pwm_input_from_rf(RC_CHANNEL_FLAG) > 50)
if(0)
  {
    drive_wheel();

    Serial.println("----------------------------------------------------- WHEEL");

  }
  else
  {
    driver_arms();

    Serial.println("xxxxxxxxxxxxxxxx-------------------------xxxxxxxxxxxxxxxx  ARM");

  }
}

void driver_arms()
{

  int speed;
  bool rpg_active = false;
  bool act1wrist_active = false;
  for (byte name = 0; name < available; name++)
  {
    speed = get_pwm_input_from_rf(channel[name]);
    if (((speed)>0?(speed):-(speed)) < 60)
      speed = 0;

    if ((speed > 0 || speed < 0))
    {
      move_it(name, speed);

      Serial.print(arm_names[name]);
      Serial.print(":\t");
      Serial.print("Speed ");
      Serial.print(speed);
      Serial.println();

    }
    else if (name == 0 || name == 2) // base act2
      move_it(name, 0);
    if (!rpg_active && speed && (name == 3 || name == 4 || name == 6)) // r p g
      rpg_active = true;
    if (!act1wrist_active && speed && (name == 1 || name == 5)) // r p g
      act1wrist_active = true;
  }

  if (!rpg_active)
    rpg.stop();
  if (!act1wrist_active)
    act1wrist360.stop();
}

const int channel_forward_backward = 2;
const int channel_left_right = 3;

void drive_wheel()
{
  int leftspeed, rightspeed, speed, direction;
  speed = get_pwm_input_from_rf(channel_forward_backward);
  direction = get_pwm_input_from_rf(channel_left_right);

  if (speed and direction)
  {
    if (speed > 0)
    {
      if (direction > 0) //assume right bound
      {
        leftspeed = speed;
        rightspeed = map(direction, 0, 250, 250, -250);
        rightspeed = middle_out(rightspeed);
      }
      else // assumed left bound
      {
        leftspeed = map(direction, 0, 250, 250, -250);
        leftspeed = middle_out(leftspeed);
        rightspeed = speed;
      }
    }
    else
    {
      leftspeed = speed;
      rightspeed = speed;
    }
  }
  else if (speed and !direction)
  {
    leftspeed = speed;
    rightspeed = speed;
  }
  else if (!speed and direction)
  {
    leftspeed = 0;
    rightspeed = 0;
  }
  else
  {
    leftspeed = 0;
    rightspeed = 0;
  }


  Serial.print("Left speed: ");
  Serial.print(leftspeed);
  Serial.print("\t");
  Serial.print("right_speed ");
  Serial.print(rightspeed);
  Serial.println("");

  move(left, leftspeed);
  move(right, rightspeed);
}
# 1 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void setup_relays()
{
  pinMode(31, 0x1);
  pinMode(33, 0x1);
  pinMode(35, 0x1);
  pinMode(37, 0x1);

  pinMode(23, 0x1);
  pinMode(25, 0x1);
  pinMode(27, 0x1);
  pinMode(29, 0x1);

  digitalWrite(31, 1);
  digitalWrite(33, 1);
  digitalWrite(35, 1);
  digitalWrite(37, 1);

  digitalWrite(23, 1);
  digitalWrite(25, 1);
  digitalWrite(27, 1);
  digitalWrite(29, 1);
}

void select_motor(int arm_name)
{
  switch (arm_name)
  {
    case 1:
      digitalWrite(31, 1);
      digitalWrite(33, 1);
      break;
    case 5:
      digitalWrite(31, 0);
      digitalWrite(33, 0);
      break;
    case 3:
      digitalWrite(23, 1);
      digitalWrite(25, 1);
      digitalWrite(27, 0);
      digitalWrite(29, 1);
      break;
    case 4:
      digitalWrite(23, 0);
      digitalWrite(25, 0);
      digitalWrite(27, 0);
      digitalWrite(29, 1);
      break;
    case 6:
      digitalWrite(23, 1);
      digitalWrite(25, 0);
      digitalWrite(27, 1);
      digitalWrite(29, 1);
      break;
  }
}

void move_it(int name, int pwm)
{
  Serial.print(arm_names[name]);
  Serial.print(' ');
  switch (name)
  {
    case 0:
      move(base, pwm);
      break;
    case 1:
      if (pwm)
        select_motor(1);
      move(act1wrist360, pwm);
      break;
    case 2:
      move(act2, pwm);
      break;
    case 3:
      if (pwm)
        select_motor(3);
      move(rpg, pwm);
      break;
    case 4:
      if (pwm)
        select_motor(4);
      move(rpg, pwm);
      break;
    case 5:
      if (pwm)
        select_motor(5);
      move(act1wrist360, pwm);
      break;
    case 6:
      if (pwm)
        select_motor(6);
      move(rpg, pwm);
      break;
  }
}

void move(IBT arm, int pwm)
{

  if (pwm < 0)
  {
    pwm = (-1) * pwm;
    arm.rotNeg(pwm);
    Serial.println("----------------------------------------NEG");
  }
  else if (pwm > 0)
  {
    arm.rotPos(pwm);
    Serial.println("----------------------------------------POS");
  }
  else
  {
    arm.stop();
//    Serial.println("---------------------------------------- 0");
  }
}
