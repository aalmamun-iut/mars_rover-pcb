#include <Arduino.h>
#line 1 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
#line 1 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
#include "IBT.h"
#include <SBUS.h>
// Macro debug def
#define ARM_DEBUG
#define WHEEL_DEBUG
#define DEBUG

#define AUTO 0
#define MANUAL 1
#define MANUAL_IK 2

#define RC_SENSITIVITY_THRESHOLD 40
#define RC_CHANNEL_FLAG 9

#define BASE 0
#define ACT1 1
#define ACT2 2
#define ROLL 3
#define PITCH 4
#define WRIST 5
#define GRABBER 6
#define FOWARD_BACKWARD 7
#define LEFT_RITGHT 8
#define LEFT_RITGHT 8

// 12 v realy pins
#define RELAY_12V_CH1 31
#define RELAY_12V_CH2 33
#define RELAY_12V_CH3 35
#define RELAY_12V_CH4 37

// 24 relay pins
#define RELAY_24V_CH1 23
#define RELAY_24V_CH2 25
#define RELAY_24V_CH3 27
#define RELAY_24V_CH4 29

//8 channel receiver
int ch[8];

IBT base(6, 7);         // wiper on base
IBT act1wrist360(10, 11); // actuator1 and wrist360
IBT act2(14, 15);         // actuator2
IBT rpg(8, 9);            // roll pitch grabber in a single relay
IBT left(12, 12);
IBT right(12, 12);
//
//IBT base(10, 11);         // wiper on base
//IBT act1wrist360(6, 7); // actuator1 and wrist360
//IBT act2(14, 15);         // actuator2
//IBT rpg(8, 9);            // roll pitch grabber in a single relay
//IBT left(12, 12);
//IBT right(12, 12);


/////////////////ba, ac1, ac2, roll, pitc, w, g
String arm_names[] = {
    "Base",
    "Act1",
    "Act2",
    "Roll",
    "Pitc",
    "Wrst",
    "Grab",
};





SBUS sbus(Serial1);
int mode;                       // mannual auto semi_auto serial
String inputString = "";        // a string to hold incoming data
boolean stringComplete = false; // whether the string is complete

#line 76 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
void setup();
#line 92 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
void loop();
#line 105 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
void test();
#line 129 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
void serialEvent();
#line 3 "F:\\erc2018\\github\\manoeuvre\\RECIEVER.ino"
void reciever_test();
#line 17 "F:\\erc2018\\github\\manoeuvre\\RECIEVER.ino"
int get_pwm_input_from_rf(byte channel_id);
#line 1 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
bool near(int from, int to, int tolerance);
#line 8 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
bool near(double from, double to, double tolerance);
#line 15 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
bool near(double from, double to, int tolerance);
#line 22 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
double rad2deg(double rad);
#line 27 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
int middle_out(int value);
#line 2 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
void handle_serial(String cmd);
#line 32 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
void only_rf_full();
#line 51 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
void driver_arms();
#line 91 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
void drive_wheel();
#line 1 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void setup_relays();
#line 24 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void select_motor(int arm_name);
#line 57 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void move_it(int name, int pwm);
#line 97 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void move(IBT arm, int pwm);
#line 76 "F:\\erc2018\\github\\manoeuvre\\manoeuvre.ino"
void setup()
{
  Serial.begin(57600);
  sbus.begin(true);
  // reserve 200 bytes for the inputString:
  inputString.reserve(200);
  //receiver setup
  setup_relays();

}

ISR(TIMER2_COMPA_vect)
{
  sbus.process();
}

void loop()
{
  //  act1wrist360.rotPos(200);
  //  delay(2000);
  //  act1wrist360.rotPos(0);
  //  delay(1000);
  //  act1wrist360.rotPos(-200);
  //  delay(2000);
  //  act1wrist360.rotPos(0);
  //  delay(1000);
  test();
}

void test()
{
//     only_rf_full();
  // only_serial_full();
  //   reciever_test();
  // print the string when a newline arrives:
  if (stringComplete)
  {
    Serial.println(inputString);
    handle_serial(inputString);
    // clear the string:
    inputString = "";
    stringComplete = false;
  }

}


/*
  SerialEvent occurs whenever a new data comes in the
  hardware serial RX.  This routine is run between each
  time loop() runs, so using delay inside loop can delay
  response.  Multiple bytes of data may be available.
*/
void serialEvent()
{
  while (Serial.available())
  {
    // get the new byte:
    char inChar = (char)Serial.read();
    // add it to the inputString:
    inputString += inChar;
    // if the incoming character is a newline, set a flag
    // so the main loop can do something about it:
    if (inChar == '\n')
    {
      stringComplete = true;
    }
  }
}

// void serialevent()
// {
//   if (Serial.available())
//   {
//    while (Serial.available())
//     {
//       var = Serial.read();
//       if (var == '\n')
//       {
//         while (Serial.available())
//           var = Serial.read();
//         break;
//       }
//       IncomingData += String(var);
//     }
//     Serial.println(IncomingData);
//     dir = (char)IncomingData[0];
//     num1 = IncomingData.substring(0, 4).toInt();
//     num2 = IncomingData.substring(4, 8).toInt();
//     num3 = IncomingData.substring(8, 12).toInt();
//     x = num1;
//     y = num2;
//     z = num3;
//     Serial.print("x : ");
//     Serial.print(x);
//     Serial.print(" y : ");
//     Serial.print(y);
//     Serial.print(" z : ");
//     Serial.println(z);
//     while (Serial.available())
//       var = Serial.read();
//     IncomingData = "";
//   }
// }

// void armtest()
// {
//   while (Serial.available())
//   {
//     char c = Serial.read();
//     if (c == 'q')
//       pitch.rotPos(150);
//     if (c == 'z')
//       pitch.rotNeg(150);
//     if (c == 'a')
//       pitch.stop();

//     if (c == 'w')
//       roll.rotPos(150);
//     if (c == 'x')
//       roll.rotNeg(150);
//     if (c == 's')
//       roll.stop();

//     if (c == 'e')
//       act2.rotPos(250);
//     if (c == 'c')
//       act2.rotNeg(250);
//     if (c == 'd')
//       act2.stop();

//     if (c == 'r')
//       act1.rotPos(250);
//     if (c == 'v')
//       act1.rotNeg(250);
//     if (c == 'f')
//       act1.stop();
//   }
// }

//  mode = get_mode();
// mode = MANUAL;
// if (mode == AUTO)
// {
//   automate();
// }
// else {
//   handle_rf();
// }

#line 1 "F:\\erc2018\\github\\manoeuvre\\RECIEVER.ino"
#define NO_OF_CHANNELS 10

void reciever_test()
{
  for (int channel_id = 1; channel_id <= NO_OF_CHANNELS; channel_id++)
  {
    Serial.print("Ch");
    Serial.print(channel_id);
    Serial.print(' ');
    Serial.print(sbus.getChannel(channel_id));
    Serial.print('\t');
  }
  Serial.println();
}

int temp_ch;
int get_pwm_input_from_rf(byte channel_id)
{
  /* 
  * Method getNormalizedChannel return -100 to +100
  * so to convert into PWM values 2.5 is multiplied 
  * to get a eange of -255 to 255
  */
  int pwm = (int)sbus.getNormalizedChannel((int)channel_id) * 2.5;

  if (abs(pwm) < RC_SENSITIVITY_THRESHOLD)
    pwm = 0;
    
  return pwm;
}
#line 1 "F:\\erc2018\\github\\manoeuvre\\a_helper_methods.ino"
bool near(int from, int to, int tolerance)
{
  if (abs(from - to) <= tolerance)
    return true;
  return false;
}

bool near(double from, double to, double tolerance)
{
  if (abs(from - to) <= tolerance)
    return true;
  return false;
}

bool near(double from, double to, int tolerance)
{
  if (abs(from - to) <= tolerance)
    return true;
  return false;
}

double rad2deg(double rad)
{
  return ((rad * 57296) / 1000);
}

int middle_out(int value)
{
  if (value < 0 and abs(value) < RC_SENSITIVITY_THRESHOLD)
    value = (-1) * RC_SENSITIVITY_THRESHOLD;
  else if (value > 0 and abs(value) < RC_SENSITIVITY_THRESHOLD)
    value = RC_SENSITIVITY_THRESHOLD;
  return value;
}

// void sonar_test()
// {
//   Serial.print("Act 1: ");
//   Serial.print(sonar_act1.get_distance());
//   Serial.print('\t');
//   Serial.print("Act 2: ");
//   Serial.print(sonar_act2.get_distance());
//   Serial.println();
// }
#line 1 "F:\\erc2018\\github\\manoeuvre\\handle_commands.ino"
// --------------------------------
void handle_serial(String cmd)
{
  int speed;
  for (int i = 0; i < 3; i++)
  {
    Serial.print(cmd[i]);
    if (cmd[i] == '+')
      speed = 200;
    else if (cmd[i] == '-')
      speed = -200;
    else
      speed = 0;
    move_it(i, speed);
  }
    Serial.println("---------");
}
// ---------------------------------- Fully manual control

int channel[7] = {
    //channel name index
    7, // base  0
    2, // ac1   1
    3, // ac2   2
    6, // roll  3
    5, //pitch  4
    4, //wrist  5
    1, //grabb  6
};
int available = 10;

void only_rf_full()
{
//  if (get_pwm_input_from_rf(RC_CHANNEL_FLAG) > 50)
if(0)
  {
    drive_wheel();
#ifdef DEBUG
    Serial.println("----------------------------------------------------- WHEEL");
#endif
  }
  else
  {
    driver_arms();
#ifdef DEBUG
    Serial.println("xxxxxxxxxxxxxxxx-------------------------xxxxxxxxxxxxxxxx  ARM");
#endif
  }
}

void driver_arms()
{
  
  int speed;
  bool rpg_active = false;
  bool act1wrist_active = false;
  for (byte name = 0; name < available; name++)
  {
    speed = get_pwm_input_from_rf(channel[name]);
    if (abs(speed) < 60)
      speed = 0;

    if ((speed > 0 || speed < 0))
    {
      move_it(name, speed);
#ifdef DEBUG &&ARM_DEBUG
      Serial.print(arm_names[name]);
      Serial.print(":\t");
      Serial.print("Speed ");
      Serial.print(speed);
      Serial.println();
#endif
    }
    else if (name == 0 || name == 2) // base act2
      move_it(name, 0);
    if (!rpg_active && speed && (name == 3 || name == 4 || name == 6)) // r p g
      rpg_active = true;
    if (!act1wrist_active && speed && (name == 1 || name == 5)) // r p g
      act1wrist_active = true;
  }

  if (!rpg_active)
    rpg.stop();
  if (!act1wrist_active)
    act1wrist360.stop();
}

const int channel_forward_backward = 2;
const int channel_left_right = 3;

void drive_wheel()
{
  int leftspeed, rightspeed, speed, direction;
  speed = get_pwm_input_from_rf(channel_forward_backward);
  direction = get_pwm_input_from_rf(channel_left_right);

  if (speed and direction)
  {
    if (speed > 0)
    {
      if (direction > 0) //assume right bound
      {
        leftspeed = speed;
        rightspeed = map(direction, 0, 250, 250, -250);
        rightspeed = middle_out(rightspeed);
      }
      else // assumed left bound
      {
        leftspeed = map(direction, 0, 250, 250, -250);
        leftspeed = middle_out(leftspeed);
        rightspeed = speed;
      }
    }
    else
    {
      leftspeed = speed;
      rightspeed = speed;
    }
  }
  else if (speed and !direction)
  {
    leftspeed = speed;
    rightspeed = speed;
  }
  else if (!speed and direction)
  {
    leftspeed = 0;
    rightspeed = 0;
  }
  else
  {
    leftspeed = 0;
    rightspeed = 0;
  }

#ifdef DEBUG &&WHEEL_DEBUG
  Serial.print("Left speed: ");
  Serial.print(leftspeed);
  Serial.print("\t");
  Serial.print("right_speed ");
  Serial.print(rightspeed);
  Serial.println("");
#endif
  move(left, leftspeed);
  move(right, rightspeed);
}

#line 1 "F:\\erc2018\\github\\manoeuvre\\movement.ino"
void setup_relays()
{
  pinMode(RELAY_12V_CH1, OUTPUT);
  pinMode(RELAY_12V_CH2, OUTPUT);
  pinMode(RELAY_12V_CH3, OUTPUT);
  pinMode(RELAY_12V_CH4, OUTPUT);

  pinMode(RELAY_24V_CH1, OUTPUT);
  pinMode(RELAY_24V_CH2, OUTPUT);
  pinMode(RELAY_24V_CH3, OUTPUT);
  pinMode(RELAY_24V_CH4, OUTPUT);

  digitalWrite(RELAY_12V_CH1, 1);
  digitalWrite(RELAY_12V_CH2, 1);
  digitalWrite(RELAY_12V_CH3, 1);
  digitalWrite(RELAY_12V_CH4, 1);

  digitalWrite(RELAY_24V_CH1, 1);
  digitalWrite(RELAY_24V_CH2, 1);
  digitalWrite(RELAY_24V_CH3, 1);
  digitalWrite(RELAY_24V_CH4, 1);
}

void select_motor(int arm_name)
{
  switch (arm_name)
  {
    case ACT1:
      digitalWrite(RELAY_12V_CH1, 1);
      digitalWrite(RELAY_12V_CH2, 1);
      break;
    case WRIST:
      digitalWrite(RELAY_12V_CH1, 0);
      digitalWrite(RELAY_12V_CH2, 0);
      break;
    case ROLL:
      digitalWrite(RELAY_24V_CH1, 1);
      digitalWrite(RELAY_24V_CH2, 1);
      digitalWrite(RELAY_24V_CH3, 0);
      digitalWrite(RELAY_24V_CH4, 1);
      break;
    case PITCH:
      digitalWrite(RELAY_24V_CH1, 0);
      digitalWrite(RELAY_24V_CH2, 0);
      digitalWrite(RELAY_24V_CH3, 0);
      digitalWrite(RELAY_24V_CH4, 1);
      break;
    case GRABBER:
      digitalWrite(RELAY_24V_CH1, 1);
      digitalWrite(RELAY_24V_CH2, 0);
      digitalWrite(RELAY_24V_CH3, 1);
      digitalWrite(RELAY_24V_CH4, 1);
      break;
  }
}

void move_it(int name, int pwm)
{
  Serial.print(arm_names[name]);
  Serial.print(' ');
  switch (name)
  {
    case BASE:
      move(base, pwm);
      break;
    case ACT1:
      if (pwm)
        select_motor(ACT1);
      move(act1wrist360, pwm);
      break;
    case ACT2:
      move(act2, pwm);
      break;
    case ROLL:
      if (pwm)
        select_motor(ROLL);
      move(rpg, pwm);
      break;
    case PITCH:
      if (pwm)
        select_motor(PITCH);
      move(rpg, pwm);
      break;
    case WRIST:
      if (pwm)
        select_motor(WRIST);
      move(act1wrist360, pwm);
      break;
    case GRABBER:
      if (pwm)
        select_motor(GRABBER);
      move(rpg, pwm);
      break;
  }
}

void move(IBT arm, int pwm)
{

  if (pwm < 0)
  {
    pwm = (-1) * pwm;
    arm.rotNeg(pwm);
    Serial.println("----------------------------------------NEG");
  }
  else if (pwm > 0)
  {
    arm.rotPos(pwm);
    Serial.println("----------------------------------------POS");
  }
  else
  {
    arm.stop();
//    Serial.println("---------------------------------------- 0");
  }
}



