close all;
clear all;
angle = [68 ,75, 100, 110, 123, 132, 153];
dist = [318, 770, 1160, 1260, 1580, 1675, 1900];
plot(dist,angle)