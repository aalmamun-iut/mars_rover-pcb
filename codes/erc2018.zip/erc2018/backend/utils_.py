import time
current_milli_time = lambda: int(round(time.time() * 1000))